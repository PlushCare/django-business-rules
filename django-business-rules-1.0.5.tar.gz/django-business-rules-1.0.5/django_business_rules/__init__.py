
default_app_config = 'django_business_rules.apps.DbrAppConfig'
