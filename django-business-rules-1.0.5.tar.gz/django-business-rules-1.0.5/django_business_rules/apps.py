from __future__ import unicode_literals

from django.apps import AppConfig


class DbrAppConfig(AppConfig):
    name = 'django_business_rules'
    verbose_name = 'Django Business Rules'
